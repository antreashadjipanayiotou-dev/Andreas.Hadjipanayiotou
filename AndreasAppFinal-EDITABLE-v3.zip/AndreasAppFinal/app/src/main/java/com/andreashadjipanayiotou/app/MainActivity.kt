package com.andreashadjipanayiotou.app

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.MimeTypeMap
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.UUID

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var filePathCallback: ValueCallback<Array<Uri>>? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView?, request: android.webkit.WebResourceRequest?): WebResourceResponse? {
                val uri = request?.url ?: return super.shouldInterceptRequest(view, request)
                if (uri.scheme == "appaudio") {
                    val name = uri.host ?: return null
                    val safe = File(name).name
                    val audioFile = File(File(filesDir, "audio"), safe)
                    if (audioFile.exists()) {
                        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(audioFile.extension) ?: "audio/mpeg"
                        return WebResourceResponse(mime, "binary", FileInputStream(audioFile))
                    }
                }
                return super.shouldInterceptRequest(view, request)
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView?,
                filePath: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                filePathCallback?.onReceiveValue(null)
                filePathCallback = filePath
                return try {
                    val intent = fileChooserParams?.createIntent()
                        ?: Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                            addCategory(Intent.CATEGORY_OPENABLE)
                            type = "image/*"
                        }
                    startActivityForResult(intent, 1001)
                    true
                } catch (_: Exception) {
                    filePathCallback = null
                    false
                }
            }
        }
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.settings.allowContentAccess = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.settings.cacheMode = WebSettings.LOAD_DEFAULT
        web.addJavascriptInterface(AndroidBridge(), "AndroidBridge")
        web.loadUrl("file:///android_asset/index.html")
        setContentView(web)
    }

    inner class AndroidBridge {
        @JavascriptInterface
        fun pickAudio() {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "audio/mpeg"
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
            }
            startActivityForResult(intent, 2002)
        }
    }

    private fun copyAudioToApp(uri: Uri): String? {
        val dir = File(filesDir, "audio")
        if (!dir.exists()) dir.mkdirs()
        val fileName = "${UUID.randomUUID()}.mp3"
        val target = File(dir, fileName)
        return try {
            contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(target).use { output ->
                    val buffer = ByteArray(8192)
                    var n: Int
                    while (input.read(buffer).also { n = it } > 0) output.write(buffer, 0, n)
                }
            } ?: return null
            "appaudio://$fileName"
        } catch (_: Exception) {
            target.delete()
            null
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1001) {
            val results = if (resultCode == RESULT_OK && data?.data != null) arrayOf(data.data!!) else null
            filePathCallback?.onReceiveValue(results)
            filePathCallback = null
        } else if (requestCode == 2002 && resultCode == RESULT_OK && data?.data != null) {
            val uri = data.data!!
            val audioUrl = copyAudioToApp(uri)
            val name = uri.lastPathSegment?.substringAfterLast('/') ?: "MP3"
            if (audioUrl != null) {
                val js = "window.onNativeAudioSelected(${org.json.JSONObject.quote(audioUrl)}, ${org.json.JSONObject.quote(name)});"
                web.post { web.evaluateJavascript(js, null) }
            } else {
                web.post { web.evaluateJavascript("alert('Δεν μπόρεσα να αποθηκεύσω το MP3.');", null) }
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (::web.isInitialized && web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}
